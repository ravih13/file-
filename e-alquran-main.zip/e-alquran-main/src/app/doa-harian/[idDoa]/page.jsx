import React from 'react';

const DetailDoa = () => {
  return (
    <>
      <div>dada</div>
    </>
  );
};

export default DetailDoa;
