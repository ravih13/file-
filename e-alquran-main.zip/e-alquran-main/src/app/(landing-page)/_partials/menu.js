const menu = [
  {
    href: '/',
    image: '/assets/images/quran.png',
    title: 'Al-Quran',
  },
  {
    href: '/doa-harian',
    image: '/assets/svg/doa.svg',
    title: 'Doa Harian',
  },
  {
    href: '/bacaan-shalat',
    image: '/assets/svg/shalat.svg',
    title: 'Bacaan Shalat',
  },
  {
    href: '/bacaan-shalat',
    image: '/assets/svg/shalat.svg',
    title: 'Ayat Kursi',
  },
];

export default menu;
